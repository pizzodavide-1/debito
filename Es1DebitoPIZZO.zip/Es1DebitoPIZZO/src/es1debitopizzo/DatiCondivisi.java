/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es1debitopizzo;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pizzo_davide
 */
public class DatiCondivisi {
    
    private Semaphore s1;
    private Semaphore s2;
    private Semaphore s3;
    private Semaphore s4;
    
    public DatiCondivisi(){
    this.s1=new Semaphore(0);
    this.s2=new Semaphore(1);
    this.s3=new Semaphore(0);
    this.s4=new Semaphore(1);
    }
    
    public void SignalS1(){
    s1.release();
    }
    public void SignalS2(){
    s2.release();
    }
    public void SignalS3(){
    s3.release();
    }
    public void SignalS4(){
    s4.release();
    }
    public void WaitS1(){
        try {
            s1.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(DatiCondivisi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void WaitS2(){
        try {
            s2.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(DatiCondivisi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void WaitS3(){
        try {
            s3.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(DatiCondivisi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void WaitS4(){
        try {
            s4.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(DatiCondivisi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    }

